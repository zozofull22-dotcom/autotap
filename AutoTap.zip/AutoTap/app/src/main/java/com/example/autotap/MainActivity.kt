package com.example.autotap

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import java.io.File

class MainActivity : Activity() {
    private val PICK = 1
    private val CAP = 2
    private lateinit var status: TextView
    private val dir get() = File(filesDir, "templates").also { it.mkdirs() }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContentView(R.layout.activity_main)
        requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 0)
        status = findViewById(R.id.status)
        findViewById<Button>(R.id.btnPick).setOnClickListener {
            startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).apply {
                type = "image/*"; putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            }, PICK)
        }
        findViewById<Button>(R.id.btnClear).setOnClickListener { dir.listFiles()?.forEach { it.delete() }; refresh() }
        findViewById<Button>(R.id.btnAcc).setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        findViewById<Button>(R.id.btnStart).setOnClickListener {
            if (ClickService.instance == null) { Toast.makeText(this, "فعّل خدمة إمكانية الوصول أولاً", Toast.LENGTH_LONG).show(); return@setOnClickListener }
            if (dir.listFiles().isNullOrEmpty()) { Toast.makeText(this, "أضف صوراً أولاً", Toast.LENGTH_LONG).show(); return@setOnClickListener }
            val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            startActivityForResult(mpm.createScreenCaptureIntent(), CAP)
        }
        findViewById<Button>(R.id.btnStop).setOnClickListener {
            startService(Intent(this, CaptureService::class.java).setAction("STOP"))
        }
        refresh()
    }

    private fun refresh() { status.text = "الصور المحفوظة: ${dir.listFiles()?.size ?: 0}" }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (res != RESULT_OK || data == null) return
        if (req == PICK) {
            val uris = mutableListOf<android.net.Uri>()
            data.data?.let { uris += it }
            data.clipData?.let { c -> for (i in 0 until c.itemCount) uris += c.getItemAt(i).uri }
            uris.forEach { u ->
                contentResolver.openInputStream(u)?.use { ins ->
                    File(dir, "t_${System.nanoTime()}.png").outputStream().use { ins.copyTo(it) }
                }
            }
            refresh()
        } else if (req == CAP) {
            startForegroundService(Intent(this, CaptureService::class.java).putExtra("code", res).putExtra("data", data))
            moveTaskToBack(true)
        }
    }
}
