package com.example.autotap

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import org.opencv.android.OpenCVLoader
import org.opencv.android.Utils
import org.opencv.core.*
import org.opencv.imgcodecs.Imgcodecs
import org.opencv.imgproc.Imgproc
import java.io.File
import kotlin.math.roundToInt

class CaptureService : Service() {
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private lateinit var thread: HandlerThread
    private lateinit var handler: Handler
    private var running = false
    private var lastClick = 0L
    private var lastSmall: Mat? = null
    private var pending = false
    private var count = 0

    private val scale = 0.75          // تصغير اللقطة لتسريع المطابقة
    private val threshold = 0.72      // دقة المطابقة (0-1)
    private val interval = 300L       // مللي ثانية بين كل فحص
    private val cooldown = 1500L      // مهلة بعد كل ضغطة
    // عروض البحث (بالبكسل على اللقطة المصغّرة) من صغير جداً إلى كبير
    private val widths = intArrayOf(20, 27, 36, 48, 64, 86, 115, 155, 210, 280)

    private class Variant(val mat: Mat, val w: Int)
    private val variants = mutableListOf<Variant>()

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") { stop(); return START_NOT_STICKY }
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("c", "AutoTap", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "c").setContentTitle("AutoTap يعمل")
            .setSmallIcon(android.R.drawable.ic_menu_search).build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)

        OpenCVLoader.initLocal()
        loadTemplates()
        val code = intent!!.getIntExtra("code", 0)
        val data = intent.getParcelableExtra<Intent>("data")!!
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mpm.getMediaProjection(code, data)
        projection!!.registerCallback(object : MediaProjection.Callback() { override fun onStop() { stop() } }, null)

        val dm = resources.displayMetrics
        val w = dm.widthPixels; val h = dm.heightPixels
        reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        projection!!.createVirtualDisplay("cap", w, h, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, null)

        thread = HandlerThread("match").also { it.start() }
        handler = Handler(thread.looper)
        running = true
        handler.post(loop)
        return START_NOT_STICKY
    }

    // لكل صورة نجهّز نسخاً بعدة أحجام، فلا يهم حجم الصورة الأصلي
    private fun loadTemplates() {
        variants.clear()
        val files = File(filesDir, "templates").listFiles() ?: return
        count = files.size
        for (f in files) {
            val t = Imgcodecs.imread(f.absolutePath, Imgcodecs.IMREAD_GRAYSCALE)
            if (t.empty()) continue
            for (w in widths) {
                val h = (t.rows() * w.toDouble() / t.cols()).roundToInt()
                if (h < 10) continue
                if (w > t.cols() * 1.5) continue
                val v = Mat()
                Imgproc.resize(t, v, Size(w.toDouble(), h.toDouble()), 0.0, 0.0,
                    if (w < t.cols()) Imgproc.INTER_AREA else Imgproc.INTER_LINEAR)
                val mean = MatOfDouble(); val std = MatOfDouble()
                Core.meanStdDev(v, mean, std)
                if (std.toArray()[0] < 8.0) continue   // تجاهل الأشكال المسطحة بلا تفاصيل
                variants.add(Variant(v, w))
            }
            t.release()
        }
    }

    private val loop = object : Runnable {
        override fun run() {
            if (!running) return
            try { scan() } catch (_: Exception) {}
            handler.postDelayed(this, interval)
        }
    }

    private fun notify(text: String) {
        val n = Notification.Builder(this, "c").setContentTitle("AutoTap يعمل")
            .setContentText(text).setSmallIcon(android.R.drawable.ic_menu_search).build()
        getSystemService(NotificationManager::class.java).notify(1, n)
    }

    private fun scan() {
        var fresh = false
        val img = reader?.acquireLatestImage()
        if (img != null) {
            val plane = img.planes[0]
            val rowPad = plane.rowStride - plane.pixelStride * img.width
            val full = Bitmap.createBitmap(img.width + rowPad / plane.pixelStride, img.height, Bitmap.Config.ARGB_8888)
            full.copyPixelsFromBuffer(plane.buffer)
            val w = img.width; val h = img.height
            img.close()
            val bmp = Bitmap.createBitmap(full, 0, 0, w, h)
            val rgba = Mat(); Utils.bitmapToMat(bmp, rgba)
            val gray = Mat(); Imgproc.cvtColor(rgba, gray, Imgproc.COLOR_RGBA2GRAY)
            val small = Mat(); Imgproc.resize(gray, small, Size(), scale, scale, Imgproc.INTER_AREA)
            lastSmall?.release(); lastSmall = small
            rgba.release(); gray.release()
            fresh = true
        }
        val small = lastSmall ?: return
        if (!fresh && !pending) return      // الشاشة لم تتغير، لا داعي لإعادة الفحص

        var best = 0.0; var bw = 0
        var bx = 0f; var by = 0f
        for (v in variants) {
            val m = v.mat
            if (m.cols() > small.cols() || m.rows() > small.rows()) continue
            val res = Mat()
            Imgproc.matchTemplate(small, m, res, Imgproc.TM_CCOEFF_NORMED)
            val mm = Core.minMaxLoc(res)
            if (mm.maxVal > best) {
                best = mm.maxVal; bw = v.w
                bx = ((mm.maxLoc.x + m.cols() / 2.0) / scale).toFloat()
                by = ((mm.maxLoc.y + m.rows() / 2.0) / scale).toFloat()
            }
            res.release()
        }
        val canClick = System.currentTimeMillis() - lastClick >= cooldown
        pending = best >= threshold && !canClick
        notify("صور: $count | أعلى تطابق: ${"%.2f".format(best)} (حجم $bw) | الحد: $threshold")
        if (best >= threshold && canClick) {
            ClickService.tap(bx, by)
            lastClick = System.currentTimeMillis()
            pending = false
        }
    }

    private fun stop() {
        running = false
        projection?.stop(); projection = null
        stopForeground(STOP_FOREGROUND_REMOVE); stopSelf()
    }
    override fun onDestroy() { running = false; super.onDestroy() }
}
