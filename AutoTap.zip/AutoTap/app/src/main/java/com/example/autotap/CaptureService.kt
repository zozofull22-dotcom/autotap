package com.example.autotap

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import org.opencv.android.OpenCVLoader
import org.opencv.android.Utils
import org.opencv.core.*
import org.opencv.imgcodecs.Imgcodecs
import org.opencv.imgproc.Imgproc
import java.io.File

class CaptureService : Service() {
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private lateinit var thread: HandlerThread
    private lateinit var handler: Handler
    private var running = false
    private var lastClick = 0L
    private val scale = 0.5          // تصغير لتسريع المطابقة
    private val threshold = 0.85     // دقة المطابقة (0-1)
    private val interval = 400L      // مللي ثانية بين كل فحص
    private val cooldown = 1500L     // مهلة بعد كل ضغطة

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") { stop(); return START_NOT_STICKY }
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("c", "AutoTap", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "c").setContentTitle("AutoTap يعمل")
            .setSmallIcon(android.R.drawable.ic_menu_search).build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)

        OpenCVLoader.initLocal()
        val code = intent!!.getIntExtra("code", 0)
        val data = intent.getParcelableExtra<Intent>("data")!!
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mpm.getMediaProjection(code, data)
        projection!!.registerCallback(object : MediaProjection.Callback() { override fun onStop() { stop() } }, null)

        val dm = resources.displayMetrics
        val w = dm.widthPixels; val h = dm.heightPixels
        reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        projection!!.createVirtualDisplay("cap", w, h, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, null)

        thread = HandlerThread("match").also { it.start() }
        handler = Handler(thread.looper)
        running = true
        handler.post(loop)
        return START_NOT_STICKY
    }

    private val loop = object : Runnable {
        override fun run() {
            if (!running) return
            try { scan() } catch (_: Exception) {}
            handler.postDelayed(this, interval)
        }
    }

    private fun scan() {
        if (System.currentTimeMillis() - lastClick < cooldown) return
        val img = reader?.acquireLatestImage() ?: return
        val plane = img.planes[0]
        val rowPad = plane.rowStride - plane.pixelStride * img.width
        val bmp = Bitmap.createBitmap(img.width + rowPad / plane.pixelStride, img.height, Bitmap.Config.ARGB_8888)
        bmp.copyPixelsFromBuffer(plane.buffer)
        img.close()

        val rgba = Mat(); Utils.bitmapToMat(bmp, rgba); bmp.recycle()
        val gray = Mat(); Imgproc.cvtColor(rgba, gray, Imgproc.COLOR_RGBA2GRAY)
        val small = Mat(); Imgproc.resize(gray, small, Size(), scale, scale, Imgproc.INTER_AREA)

        val dir = File(filesDir, "templates")
        for (f in dir.listFiles() ?: return) {
            val t = Imgcodecs.imread(f.absolutePath, Imgcodecs.IMREAD_GRAYSCALE)
            if (t.empty()) continue
            val ts = Mat(); Imgproc.resize(t, ts, Size(), scale, scale, Imgproc.INTER_AREA)
            if (ts.cols() > small.cols() || ts.rows() > small.rows()) continue
            val res = Mat()
            Imgproc.matchTemplate(small, ts, res, Imgproc.TM_CCOEFF_NORMED)
            val mm = Core.minMaxLoc(res)
            if (mm.maxVal >= threshold) {
                val cx = ((mm.maxLoc.x + ts.cols() / 2.0) / scale).toFloat()
                val cy = ((mm.maxLoc.y + ts.rows() / 2.0) / scale).toFloat()
                ClickService.tap(cx, cy)
                lastClick = System.currentTimeMillis()
                break
            }
        }
    }

    private fun stop() {
        running = false
        projection?.stop(); projection = null
        stopForeground(STOP_FOREGROUND_REMOVE); stopSelf()
    }
    override fun onDestroy() { running = false; super.onDestroy() }
}
